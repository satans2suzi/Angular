# Authentication

You should replace the APIs with your owns in `login.service.ts`

- `/auth/login` Login
- `/auth/refresh` Refresh
- `/auth/logout` Logout
- `/me` Get user information
- `/me/menu` Get user menu
